
public interface List<T> {
	boolean isEmpty();
	int size();
	void add(T element);
	void addEl(int index, T element);
	void clear();
	T get(int index);
	
}
