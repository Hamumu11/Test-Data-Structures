class Node<T>{
	private T data;
	private Node<T> next;
	
	public Node(T data, Node<T> next)
	{
		this.data = data;
		this.next = next;
	}
	
	public Node(T data)
	{
		this(data, null);
	}
	
	public void setData(T data)
	{
		this.data = data;
	}
	
	public T getData()
	{
		return data;
	}
	
	public void setNext(Node<T> next)
	{
		this.next = next;
	}
	
	
	public Node<T> getNext()
	{
		return next;
	}
}

public  class CycleLinkedList<T> implements List<T>{
	private Node<T> start;
	private Node<T> end;
	private int size;
	
	@Override
	public boolean isEmpty() {
		return start == null;
	}

	@Override
	public int size() {
		return size;
	}

	@Override
	public void add(T element) {
		if(isEmpty())
		{
			start = new Node<T>(element);
			end = start;
			size++;
			return;
		}
		end.setNext(new Node<T>(element));
		end = end.getNext();
		end.setNext(start);
		size++;
		
	}

	@Override
	public void addEl(int index, T element) {
		
		if(index > size() || index < 0) {
			throw new IndexOutOfBoundsException();
		}
		
		Node<T> current = start;
		Node<T> previous = null;
		
		while(index > 0)
		{
			previous = current;
			current = current.getNext();
			index--;
		}
		
		if(previous == null) {
			start = new Node<T>(element,start);
		}else if(current.getNext() == null){
			current.setNext(new Node<T>(element));
			current = current.getNext();
			current.setNext(start);
		}else{
			previous.setNext(new Node<T>(element,current));
		}
		size++;
	}

	@Override
	public void clear() {
		start = end = null;
		size = 0;
	}

	@Override
	public T get(int index) {
		if(index < 0 && index*-1 <= size()) {
			index = index * -1;
			index = size() - index;
		}else if(index < 0 && index*-1 > size()) {
			index = index * -1;
			while(index >= size()) {
				index = size() - index;
				index = index * -1;
			}
			index = size() - index;
		}
		
		if(index > size()) {
			while(index > size()) {
				index = index - size();
			}
		}
		Node<T> current = start;
		while(index > 0)
		{
			current = current.getNext();
			index--;
		}
		return current.getData();
	}

}
